
console.log('foo line 1');

module.exports = function (n) { return n * 111 }
